import React from "react";
import GradeedFalse from "../images/Ellipse 180.svg";

function Isgradedfalse()
{

return(
    <>
    <div className="flex justify-center items-center">
    <img
    src={GradeedFalse}
    alt="Icon"
    className="w-[20px] h-[20px]"
  />  
  </div>

    </>
);
}

export default Isgradedfalse;